const notepad = new Notepad(initialNotes);
const listRef = document.querySelector('.note-list');
renderNoteList(listRef, notepad.notes);
// console.log(renderNoteList(listRef, notepad.notes));

Ось в стилях написано для класу note_footer display: block
Хоча у файлі StyleSheet.css прописано display: flex
У браузері змінити не дає.