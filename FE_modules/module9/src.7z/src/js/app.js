const notepad = new Notepad(initialNotes);
renderNoteList(refs.list, notepad.notes);
// console.log(renderNoteList(listRef, notepad.notes));
