function addListItem (ref, note) {
    ref.append(createListItem(note));
}